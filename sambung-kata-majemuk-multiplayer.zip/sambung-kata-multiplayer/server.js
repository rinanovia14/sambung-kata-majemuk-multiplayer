const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "public")));

const wordBank = {
  RUMAH:["sakit","makan","tangga","adat","susun","dinas","ibadah"],
  MATA:["hari","air","kaki","pelajaran","pencaharian","rantai","batin"],
  ORANG:["tua","asing","utan","lain","kaya","sakit"],
  KEPALA:["sekolah","desa","keluarga","kantor","negara","daerah"],
  MEJA:["makan","kerja","hijau","tulis","belajar"],
  ANAK:["buah","tangga","emas","didik","negeri","kandung"],
  BUAH:["tangan","hati","bibir","pikiran","karya"],
  KAKI:["tangan","lima","gunung","langit","meja"],
  TANDA:["tangan","baca","mata","tanya","seru"],
  KERETA:["api","listrik","barang","cepat"],
  KAPAL:["laut","udara","pesiar","dagang"],
  AIR:["mata","laut","hujan","terjun","panas","dingin"],
  HARI:["raya","ulang","libur","besar","kerja"],
  BUKU:["tulis","pelajaran","harian","gambar","cerita"],
  SEKOLAH:["dasar","menengah","tinggi","minggu"]
};

const rooms = new Map();

function code(){
  return Math.random().toString(36).slice(2,8).toUpperCase();
}
function clean(s){ return String(s||"").trim().toLowerCase().replace(/\s+/g," "); }
function publicRoom(r){
  return {
    code:r.code, word:r.word, round:r.round, time:r.time, running:r.running,
    groups:r.groups.map(g=>({name:g.name, score:g.score, connected:g.connected, submitted:g.submitted})),
    results:r.results
  };
}
function emitRoom(r){ io.to(r.code).emit("state", publicRoom(r)); }

io.on("connection", socket=>{
  socket.on("createRoom", ({groupCount=4}={})=>{
    let c=code(); while(rooms.has(c)) c=code();
    const groups=Array.from({length:Math.max(2,Math.min(8,groupCount))},(_,i)=>({
      name:`Kelompok ${i+1}`, score:0, connected:false, submitted:false,
      answers:[], socketId:null
    }));
    const words=Object.keys(wordBank);
    const r={code:c,word:words[0],round:1,time:30,running:false,groups,results:[],host:socket.id,timer:null};
    rooms.set(c,r); socket.join(c); socket.room=c; socket.role="host";
    socket.emit("created", publicRoom(r)); emitRoom(r);
  });

  socket.on("joinRoom", ({room,group,name}={})=>{
    const r=rooms.get(String(room||"").toUpperCase());
    if(!r) return socket.emit("errorMsg","Room tidak ditemukan.");
    const idx=Number(group)-1;
    if(!r.groups[idx]) return socket.emit("errorMsg","Kelompok tidak tersedia.");
    if(r.groups[idx].connected) return socket.emit("errorMsg","Kelompok itu sudah terhubung.");
    r.groups[idx].connected=true; r.groups[idx].socketId=socket.id;
    if(name && String(name).trim()) r.groups[idx].name=String(name).trim().slice(0,40);
    socket.join(r.code); socket.room=r.code; socket.role="player"; socket.group=idx;
    socket.emit("joined",{group:idx+1}); emitRoom(r);
  });

  socket.on("startRound",()=>{
    const r=rooms.get(socket.room);
    if(!r || socket.id!==r.host || r.running) return;
    r.running=true; r.time=30; r.results=[];
    r.groups.forEach(g=>{g.answers=[];g.submitted=false;});
    emitRoom(r);
    r.timer=setInterval(()=>{
      r.time--;
      if(r.time<=0){ finish(r); }
      else emitRoom(r);
    },1000);
  });

  socket.on("submit",({answers=[]}={})=>{
    const r=rooms.get(socket.room);
    if(!r || socket.role!=="player" || !r.running) return;
    const g=r.groups[socket.group];
    g.answers=[...new Set((Array.isArray(answers)?answers:[]).map(clean).filter(Boolean))].slice(0,30);
    g.submitted=true; emitRoom(r);
  });

  socket.on("finishRound",()=>{
    const r=rooms.get(socket.room);
    if(r && socket.id===r.host) finish(r);
  });

  socket.on("nextRound",()=>{
    const r=rooms.get(socket.room);
    if(!r || socket.id!==r.host) return;
    if(r.running) finish(r);
    const words=Object.keys(wordBank);
    let choices=words.filter(w=>w!==r.word);
    r.word=choices[Math.floor(Math.random()*choices.length)];
    r.round++; r.time=30; r.results=[]; r.running=false;
    r.groups.forEach(g=>{g.answers=[];g.submitted=false;});
    emitRoom(r);
  });

  socket.on("resetScores",()=>{
    const r=rooms.get(socket.room);
    if(!r || socket.id!==r.host) return;
    r.groups.forEach(g=>g.score=0); r.round=1; r.time=30; r.results=[];
    emitRoom(r);
  });

  socket.on("disconnect",()=>{
    const r=rooms.get(socket.room);
    if(!r) return;
    if(socket.id===r.host){
      if(r.timer) clearInterval(r.timer);
      io.to(r.code).emit("errorMsg","Host menutup permainan.");
      rooms.delete(r.code);
    } else if(socket.role==="player" && r.groups[socket.group]){
      r.groups[socket.group].connected=false;
      r.groups[socket.group].socketId=null;
      emitRoom(r);
    }
  });
});

function finish(r){
  if(r.timer) clearInterval(r.timer);
  r.timer=null; r.running=false;
  const valid=new Set(wordBank[r.word].map(clean));
  const counts={};
  r.groups.forEach(g=>g.answers.forEach(a=>counts[a]=(counts[a]||0)+1));
  r.results=r.groups.map(g=>{
    const items=g.answers.map(a=>{
      if(!valid.has(a)) return {answer:a,status:"wrong"};
      if(counts[a]>1) return {answer:a,status:"duplicate"};
      return {answer:a,status:"correct"};
    });
    const points=items.filter(x=>x.status==="correct").length;
    g.score+=points;
    return {name:g.name,items,points};
  });
  emitRoom(r);
}

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Sambung Kata Multiplayer berjalan di port ${PORT}`));
