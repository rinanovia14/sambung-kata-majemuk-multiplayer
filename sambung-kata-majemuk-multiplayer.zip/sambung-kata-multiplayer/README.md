# Sambung Kata Majemuk — Multiplayer Realtime

## Cara menjalankan di komputer
1. Install Node.js (versi LTS).
2. Buka terminal/Command Prompt di folder proyek.
3. Jalankan:
   npm install
   npm start
4. Buka http://localhost:3000/host.html sebagai dosen.
5. Untuk mahasiswa di jaringan yang sama, gunakan alamat IP komputer host, misalnya:
   http://192.168.1.10:3000/player.html
6. Dosen membuat room otomatis. Mahasiswa memasukkan kode room dan memilih kelompok.

## Untuk dimainkan dari HP di kelas
Komputer yang menjalankan server dan HP mahasiswa harus berada pada jaringan yang sama, dan firewall Windows mengizinkan Node.js. Jika ingin mahasiswa mengakses dari rumah/jaringan berbeda, proyek perlu di-host di server online.

## Aturan
- 4 kelompok.
- 30 detik per ronde.
- Jawaban benar dan unik = +1.
- Jawaban yang sama di lebih dari satu kelompok = 0 untuk semua yang memakai jawaban tersebut.
- Jawaban di luar daftar kata majemuk = 0.
